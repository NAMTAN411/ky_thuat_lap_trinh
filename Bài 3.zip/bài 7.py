print('SV : Lê Quang Trung')
print('mssv : 235752021610012')

n = int(input("Nhập vào một số: "))

d = {}

for i in range(1, n+1):
    d[i] = i * i  

print(d)
