print('sv : Lê quang Trung')
print('mssv : 235752021610012')
def say_hello():
    a = "Hello"
    print(a)

say_hello()

