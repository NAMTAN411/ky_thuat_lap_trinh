print('sv : Lê quang Trung')
print('mssv : 235752021610012')

def sum(a, b):
    print("sum = " + str(a + b))

sum(4, 5)

sum(3, 7)
