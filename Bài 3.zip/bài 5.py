print('SV : Lê Quang Trung')
print('mssv : 235752021610012')
a = "Hello Guy!" 

def say():
    global a 
    a = "Vinh University"  
    print(a)  

say() 
print(a)  
