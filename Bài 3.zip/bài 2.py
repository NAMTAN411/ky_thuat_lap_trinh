print('sv : Lê quang Trung')
print('mssv : 235752021610012')
def sum(a, b):
    return a + b

c = sum(4, 5)

print("Tổng của 4 và 5 = " + str(c))
