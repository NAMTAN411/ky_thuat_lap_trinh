print('sv : Lê quang Trung')
print('mssv : 235752021610012')
a = "Hello Guy!"  

def say(a):  
    a = "Vinh University"  
    print(a)  

say(a) 
print(a)

